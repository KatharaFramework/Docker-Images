#!/bin/sh

set -x
set -e

./katharanp
